import React from "react";
export default function Projects(){return(<section className="section" id="projects"><h2>Projects</h2>
<div className="item"><h3>AI-powered Resume Screening & Ranking System</h3></div>
<div className="item"><h3>Data Analysis on Global Terrorism</h3></div>
</section>);}